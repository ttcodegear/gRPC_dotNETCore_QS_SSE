﻿using System;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using System.Net.Http;
using Grpc.Net.Client;
using greeter_server;

namespace greeter_client
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Return `true` to allow certificates that are untrusted/invalid
            var httpHandler = new HttpClientHandler();
            httpHandler.ServerCertificateCustomValidationCallback =
                HttpClientHandler.DangerousAcceptAnyServerCertificateValidator;
            var channel = GrpcChannel.ForAddress("https://localhost:50051",
                              new GrpcChannelOptions{HttpHandler=httpHandler});
            var client = new Greeter.GreeterClient(channel);
            var request = new HelloRequest();
            request.Name = "山田太郎";
            var reply = await client.SayHelloAsync(request);
            Console.WriteLine("Greeter client received: " + reply.Message);
        }
    }
}
