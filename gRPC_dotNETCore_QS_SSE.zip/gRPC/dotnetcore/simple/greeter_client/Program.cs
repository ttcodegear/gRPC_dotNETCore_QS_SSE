﻿using System;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Grpc.Net.Client;
using greeter_server;

namespace greeter_client
{
    class Program
    {
        static async Task Main(string[] args)
        {
            AppContext.SetSwitch("System.Net.Http.SocketsHttpHandler.Http2UnencryptedSupport", true);
            var channel = GrpcChannel.ForAddress("http://localhost:50051");
            var client = new Greeter.GreeterClient(channel);
            var request = new HelloRequest();
            request.Name = "山田太郎";
            var reply = await client.SayHelloAsync(request);
            Console.WriteLine("Greeter client received: " + reply.Message);
        }
    }
}
