﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Grpc.Core;
using Microsoft.Extensions.Logging;

namespace greeter_server
{
    public class GreeterService : MultiGreeter.MultiGreeterBase
    {
        private readonly ILogger<GreeterService> _logger;
        public GreeterService(ILogger<GreeterService> logger)
        {
            _logger = logger;
        }

        public override async Task SayHello(IAsyncStreamReader<HelloRequest> requestStream, IServerStreamWriter<HelloReply> responseStream, ServerCallContext context)
        {
            await foreach(var request in requestStream.ReadAllAsync()) {
              for(int i = 0; i < int.Parse(request.NumGreetings); i++) {
                var reply = new HelloReply();
                reply.Message = "こんにちは " + request.Name + " " + i;
                await responseStream.WriteAsync(reply);
              }
            }
        }
    }
}
