﻿using System;
using System.Threading.Tasks;
using System.Runtime.InteropServices;
using Grpc.Net.Client;
using Grpc.Core;
using greeter_server;

namespace greeter_client
{
    class Program
    {
        static async Task Main(string[] args)
        {
            AppContext.SetSwitch("System.Net.Http.SocketsHttpHandler.Http2UnencryptedSupport", true);
            var channel = GrpcChannel.ForAddress("http://localhost:50052");
            var client = new MultiGreeter.MultiGreeterClient(channel);
            using var call = client.SayHello();
            var request1 = new HelloRequest();
            request1.Name = "山田太郎";
            request1.NumGreetings = "5";
            await call.RequestStream.WriteAsync(request1);
            var request2 = new HelloRequest();
            request2.Name = "FooBar";
            request2.NumGreetings = "5";
            await call.RequestStream.WriteAsync(request2);
            await call.RequestStream.CompleteAsync();
            await foreach(var reply in call.ResponseStream.ReadAllAsync()) {
              Console.WriteLine("Greeter client received: " + reply.Message);
            }
        }
    }
}
